package br.unisales.batalhaordenacao.algorithms;

public class Main {

    public static void main(String[] args) {



    }

}
